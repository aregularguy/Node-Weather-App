<?php
	$conn = new mysqli('localhost', 'root', '', 'attendance') or die(mysqli_error());